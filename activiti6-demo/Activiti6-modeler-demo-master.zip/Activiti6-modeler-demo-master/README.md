# Activiti6-modeler-demo
spring boot 1.5.8整合Activiti6.0及其Activiti-modeler

启动项目注意事项：  
1、修改yml文件数据库地址及其用户名、密码。  
2、默认启动端口为8080。  
3、访问地址：localhost:8080

![流程实例列表.png](src/main/resources/static/img/流程实例列表.png)

![流程设计器.png](src/main/resources/static/img/流程设计器.png)
